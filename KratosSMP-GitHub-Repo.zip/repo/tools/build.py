"""KratosSMP-Menu.zip uretir (deterministik) ve SHA-1 yazdirir."""
import zipfile, hashlib, os, sys
SRC = os.path.join(os.path.dirname(__file__), "..", "KratosSMP-Menu")
OUT = os.path.join(os.path.dirname(__file__), "..", "dist", "KratosSMP-Menu.zip")
os.makedirs(os.path.dirname(OUT), exist_ok=True)
files = []
for d, _, fs in os.walk(SRC):
    for f in fs:
        p = os.path.join(d, f); files.append((os.path.relpath(p, SRC).replace(os.sep, "/"), p))
files.sort()
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for arc, p in files:
        zi = zipfile.ZipInfo(arc, (2026, 1, 1, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = 0o644 << 16
        z.writestr(zi, open(p, "rb").read())
sha1 = hashlib.sha1(open(OUT, "rb").read()).hexdigest()
open(OUT + ".sha1", "w").write(sha1 + "\n")
print("SHA1:", sha1, "| boyut:", os.path.getsize(OUT) // 1024, "KB")
