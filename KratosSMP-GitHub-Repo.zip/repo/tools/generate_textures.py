"""KratosSMP menu pack - yuksek cozunurluklu (piksel olmayan) doku uretici.
Kullanim: python tools/generate_textures.py
"""
import os, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

ROOT = os.path.join(os.path.dirname(__file__), "..", "KratosSMP-Menu")
TEX = os.path.join(ROOT, "assets/minecraft/textures")
FONT = "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf"
random.seed(7); np.random.seed(7)

def hexc(h, a=255):
    h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4)) + (a,)

def vgrad(w, h, top, bot):
    t = np.linspace(0, 1, h)[:, None, None]
    a = np.array(top, float)[None, None, :] * (1 - t) + np.array(bot, float)[None, None, :] * t
    return Image.fromarray(np.repeat(a, w, axis=1).astype("uint8"), "RGBA")

def rgrad(size, inner, outer):
    y, x = np.mgrid[0:size, 0:size]
    c = (size - 1) / 2
    d = np.clip(np.sqrt((x - c) ** 2 + (y - c) ** 2) / c, 0, 1)[..., None]
    a = np.array(inner, float) * (1 - d) + np.array(outer, float) * d
    return Image.fromarray(a.astype("uint8"), "RGBA")

def mask_rrect(size, box, r):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle(box, r, fill=255)
    return m

def paste_fill(img, mask, fill):
    layer = fill if isinstance(fill, Image.Image) else Image.new("RGBA", img.size, fill)
    img.paste(layer, (0, 0), mask)

def noise_overlay(img, mask, amount=10):
    n = np.random.randint(-amount, amount + 1, (img.height, img.width, 1))
    arr = np.array(img).astype(int)
    arr[..., :3] = np.clip(arr[..., :3] + n, 0, 255)
    out = Image.fromarray(arr.astype("uint8"), "RGBA")
    img.paste(out, (0, 0), mask)

def rivet(img, cx, cy, r):
    d = ImageDraw.Draw(img)
    d.ellipse([cx - r - 3, cy - r - 3, cx + r + 3, cy + r + 3], fill=hexc("#1a0000"))
    g = rgrad(int(r * 2), hexc("#d9d9de"), hexc("#6b6b73"))
    m = Image.new("L", g.size, 0); ImageDraw.Draw(m).ellipse([0, 0, g.width - 1, g.height - 1], fill=255)
    img.paste(g, (int(cx - r), int(cy - r)), m)
    d.ellipse([cx - r * .45, cy - r * .55, cx - r * .05, cy - r * .15], fill=(255, 255, 255, 190))

# ---------------------------------------------------------------- BUTTON
def button(kind, S=8, SS=2):
    W, H = 200 * S * SS, 20 * S * SS
    u = S * SS  # 1 GUI birimi
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pal = {
        "normal": dict(out="#1a0000", b1="#ff4a4a", b2="#a80f12", in_="#2a0507", p1="#2a2a30", p2="#121215", hl=(255, 255, 255, 70)),
        "hover":  dict(out="#1a0000", b1="#ff8a7a", b2="#e0262a", in_="#3a0a0d", p1="#5a1a20", p2="#2c0a0e", hl=(255, 255, 255, 120)),
        "off":    dict(out="#0d0d0f", b1="#6a6a72", b2="#3a3a40", in_="#1a1a1d", p1="#262629", p2="#171719", hl=(255, 255, 255, 30)),
    }[kind]
    r = int(.9 * u)
    paste_fill(img, mask_rrect((W, H), (0, 0, W - 1, H - 1), r), hexc(pal["out"]))
    b = int(.7 * u)
    paste_fill(img, mask_rrect((W, H), (b, b, W - 1 - b, H - 1 - b), int(r * .8)), vgrad(W, H, hexc(pal["b1"]), hexc(pal["b2"])))
    i = int(2.3 * u)
    paste_fill(img, mask_rrect((W, H), (i, i, W - 1 - i, H - 1 - i), int(r * .5)), hexc(pal["in_"]))
    p = int(2.8 * u)
    pm = mask_rrect((W, H), (p, p, W - 1 - p, H - 1 - p), int(r * .4))
    paste_fill(img, pm, vgrad(W, H, hexc(pal["p1"]), hexc(pal["p2"])))
    noise_overlay(img, pm, 6)
    d = ImageDraw.Draw(img)
    d.line([(p + 2 * u, p + 2), (W - p - 2 * u, p + 2)], fill=pal["hl"], width=max(2, u // 4))
    # kose perçinleri (nine-slice kenar = 5 birim -> cerceve icinde kalir)
    for cx, cy in [(2.5 * u, 2.5 * u), (W - 2.5 * u, 2.5 * u), (2.5 * u, H - 2.5 * u), (W - 2.5 * u, H - 2.5 * u)]:
        rivet(img, cx, cy, 1.0 * u)
    return img.resize((200 * S, 20 * S), Image.LANCZOS)

# ---------------------------------------------------------------- TITLE
def text_mask(size, text, font, xy):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).text(xy, text, font=font, fill=255)
    return m

def title(S=8, SS=2):
    W, H = 204 * S * SS, 36 * S * SS
    u = S * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    wing = 8 * u
    # yan kanatlar
    for side in (0, 1):
        x0, x1 = (0, wing + u) if side == 0 else (W - wing - u, W)
        pts = [(x0 + (0 if side else wing), H * .5)] if False else None
        if side == 0:
            poly = [(0, H * .5), (wing * .55, H * .12), (wing + u, H * .12), (wing + u, H * .88), (wing * .55, H * .88)]
        else:
            poly = [(W, H * .5), (W - wing * .55, H * .12), (W - wing - u, H * .12), (W - wing - u, H * .88), (W - wing * .55, H * .88)]
        d.polygon(poly, fill=hexc("#1a0000"))
        inner = [(px + (u * .8 if side == 0 else -u * .8) * (1 if px < W / 2 else -1) * 0 , py) for px, py in poly]
        sm = Image.new("L", (W, H), 0); ImageDraw.Draw(sm).polygon(poly, fill=255)
        sm = sm.filter(ImageFilter.MinFilter(int(u * 1.6) | 1))
        img.paste(vgrad(W, H, hexc("#ff4a4a"), hexc("#a80f12")), (0, 0), sm)
        gx = wing * .45 if side == 0 else W - wing * .45
        rivet(img, gx, H * .5, 1.4 * u)
    # orta panel
    L, R, T, B = wing, W - wing, int(4 * u), H - int(4 * u)
    paste_fill(img, mask_rrect((W, H), (L, T, R, B), int(1.2 * u)), hexc("#1a0000"))
    paste_fill(img, mask_rrect((W, H), (L + .8 * u, T + .8 * u, R - .8 * u, B - .8 * u), int(1 * u)), vgrad(W, H, hexc("#ff4a4a"), hexc("#a80f12")))
    paste_fill(img, mask_rrect((W, H), (L + 2.4 * u, T + 2.4 * u, R - 2.4 * u, B - 2.4 * u), int(.8 * u)), hexc("#2a0507"))
    pm = mask_rrect((W, H), (L + 3 * u, T + 3 * u, R - 3 * u, B - 3 * u), int(.7 * u))
    paste_fill(img, pm, vgrad(W, H, hexc("#2b2b31"), hexc("#111114")))
    noise_overlay(img, pm, 6)
    for cx, cy in [(L + 1.6 * u, T + 1.6 * u), (R - 1.6 * u, T + 1.6 * u), (L + 1.6 * u, B - 1.6 * u), (R - 1.6 * u, B - 1.6 * u)]:
        rivet(img, cx, cy, .9 * u)
    # ust / alt elmas
    d = ImageDraw.Draw(img)
    for cy in (T, B):
        cx = W / 2; s = 2.2 * u
        d.polygon([(cx, cy - s), (cx + s, cy), (cx, cy + s), (cx - s, cy)], fill=hexc("#1a0000"))
        s2 = s * .72
        d.polygon([(cx, cy - s2), (cx + s2, cy), (cx, cy + s2), (cx - s2, cy)], fill=hexc("#ff5a5a"))
        d.ellipse([cx - s * .25, cy - s * .25, cx + s * .25, cy + s * .25], fill=(255, 255, 255, 230))
    # yazi
    f = ImageFont.truetype(FONT, int(17 * u))
    part1, part2 = "KRATOS", "SMP"
    w1 = d.textlength(part1, font=f); w2 = d.textlength(part2, font=f)
    x = (W - (w1 + w2)) / 2 - .3 * u
    y = H / 2 - 12.2 * u
    for txt, xx, top, bot in [(part1, x, "#ff6a6a", "#c40d12"), (part2, x + w1, "#ffffff", "#b9b9c4")]:
        m = text_mask((W, H), txt, f, (xx, y))
        sh = m.filter(ImageFilter.MaxFilter(int(2.6 * u) | 1))
        gl = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        paste_fill(gl, sh, hexc("#1a0000", 255))
        img.alpha_composite(Image.new("RGBA", (W, H), (0, 0, 0, 0)))
        shadow = ImageChops.offset(sh, 0, int(.9 * u)).filter(ImageFilter.GaussianBlur(u * .5))
        sd = Image.new("RGBA", (W, H), (0, 0, 0, 0)); sd.paste((0, 0, 0, 150), (0, 0), shadow)
        img.alpha_composite(sd); img.alpha_composite(gl)
        grad = vgrad(W, H, hexc(top), hexc(bot))
        gtop = int(y + 3 * u); gh = int(17 * u)
        g2 = Image.new("RGBA", (W, H), (0, 0, 0, 0)); g2.paste(vgrad(W, gh, hexc(top), hexc(bot)), (0, gtop))
        paste_fill(img, m, g2)
        # ince ust parlama
        hi = ImageChops.subtract(m, ImageChops.offset(m, 0, int(.8 * u)))
        img.paste((255, 255, 255, 120), (0, 0), hi)
    return img.resize((204 * S, 36 * S), Image.LANCZOS)

# ---------------------------------------------------------------- ICONS
def icons(S=8, SS=4):
    n = 4; cell = 10 * S * SS
    img = Image.new("RGBA", (cell * n, cell), (0, 0, 0, 0))
    def lin(poly, top, bot, out="#1a1a1f", ow=.5):
        W, H = img.size
        m = Image.new("L", (W, H), 0); ImageDraw.Draw(m).polygon(poly, fill=255)
        o = m.filter(ImageFilter.MaxFilter(int(ow * S * SS * 2) | 1))
        paste_fill(img, o, hexc(out)); paste_fill(img, m, vgrad(W, H, hexc(top), hexc(bot)))
    k = S * SS
    # 0 - kilic
    ox = 0
    lin([(ox + 8.6 * k, .8 * k), (ox + 9.4 * k, 1.6 * k), (ox + 4.4 * k, 6.6 * k), (ox + 3.6 * k, 5.8 * k)], "#f4f4f8", "#8a8a96")
    lin([(ox + 2.2 * k, 5.6 * k), (ox + 3.6 * k, 4.6 * k), (ox + 5.4 * k, 6.4 * k), (ox + 4.4 * k, 7.8 * k)], "#ff5a5a", "#a80f12")
    lin([(ox + 3.4 * k, 6.6 * k), (ox + 4.4 * k, 7.4 * k), (ox + 1.4 * k, 9.4 * k), (ox + .6 * k, 8.6 * k)], "#7a4a2a", "#3a2010")
    # 1 - disli
    import math
    cx, cy = 10 * k + 5 * k, 5 * k
    pts = []
    for i in range(16):
        a = i * math.pi / 8
        rr = 4.3 * k if i % 2 == 0 else 3.2 * k
        pts += [(cx + rr * math.cos(a - .12), cy + rr * math.sin(a - .12)), (cx + rr * math.cos(a + .12), cy + rr * math.sin(a + .12))]
    lin(pts, "#ffe066", "#d99a00", "#3a2400")
    dd = ImageDraw.Draw(img); dd.ellipse([cx - 1.6 * k, cy - 1.6 * k, cx + 1.6 * k, cy + 1.6 * k], fill=(0, 0, 0, 0))
    m = Image.new("L", img.size, 0); ImageDraw.Draw(m).ellipse([cx - 1.6 * k, cy - 1.6 * k, cx + 1.6 * k, cy + 1.6 * k], fill=255)
    img.paste((0, 0, 0, 0), (0, 0), m)
    # 2 - bayrak
    ox = 20 * k
    lin([(ox + 1.8 * k, .8 * k), (ox + 2.6 * k, .8 * k), (ox + 2.6 * k, 9.4 * k), (ox + 1.8 * k, 9.4 * k)], "#d9d9de", "#6b6b73")
    lin([(ox + 2.6 * k, 1 * k), (ox + 8.8 * k, 1.8 * k), (ox + 7.4 * k, 3.6 * k), (ox + 8.8 * k, 5.4 * k), (ox + 2.6 * k, 5 * k)], "#ff5a5a", "#b3101a")
    # 3 - kapi/kemer
    ox = 30 * k
    arch = [(ox + 1.2 * k, 9.4 * k), (ox + 1.2 * k, 4.4 * k)]
    for i in range(1, 12):
        a = math.pi - i * math.pi / 11
        arch.append((ox + 5 * k + 3.8 * k * math.cos(a), 4.4 * k - 3.6 * k * math.sin(a)))
    arch += [(ox + 8.8 * k, 4.4 * k), (ox + 8.8 * k, 9.4 * k)]
    lin(arch, "#c9c9d2", "#6b6b73")
    inner = [(ox + 2.8 * k, 9.4 * k), (ox + 2.8 * k, 4.6 * k)]
    for i in range(1, 12):
        a = math.pi - i * math.pi / 11
        inner.append((ox + 5 * k + 2.2 * k * math.cos(a), 4.6 * k - 2.2 * k * math.sin(a)))
    inner += [(ox + 7.2 * k, 4.6 * k), (ox + 7.2 * k, 9.4 * k)]
    lin(inner, "#1a1a22", "#08080b", out="#08080b", ow=.1)
    return img.resize((cell // SS * n, cell // SS), Image.LANCZOS)

# ---------------------------------------------------------------- PACK ICON
def pack_icon(size=512, SS=2):
    W = size * SS
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    paste_fill(img, mask_rrect((W, W), (0, 0, W - 1, W - 1), W // 8), hexc("#1a0000"))
    paste_fill(img, mask_rrect((W, W), (W // 40, W // 40, W - W // 40, W - W // 40), W // 9), vgrad(W, W, hexc("#ff4a4a"), hexc("#a80f12")))
    pm = mask_rrect((W, W), (W // 14, W // 14, W - W // 14, W - W // 14), W // 11)
    paste_fill(img, pm, vgrad(W, W, hexc("#2b2b31"), hexc("#111114")))
    f = ImageFont.truetype(FONT, int(W * .66))
    d = ImageDraw.Draw(img)
    bb = d.textbbox((0, 0), "K", font=f)
    xy = ((W - (bb[2] - bb[0])) / 2 - bb[0], (W - (bb[3] - bb[1])) / 2 - bb[1])
    m = text_mask((W, W), "K", f, xy)
    paste_fill(img, m.filter(ImageFilter.MaxFilter(W // 60 * 2 + 1)), hexc("#1a0000"))
    paste_fill(img, m, vgrad(W, W, hexc("#ff6a6a"), hexc("#c40d12")))
    for cx, cy in [(W * .11,) * 2, (W * .89, W * .11), (W * .11, W * .89), (W * .89,) * 2]:
        rivet(img, cx, cy, W * .028)
    return img.resize((size, size), Image.LANCZOS)

if __name__ == "__main__":
    os.makedirs(os.path.join(TEX, "gui/sprites/widget"), exist_ok=True)
    for name, kind in [("button", "normal"), ("button_highlighted", "hover"), ("button_disabled", "off")]:
        button(kind).save(os.path.join(TEX, f"gui/sprites/widget/{name}.png"), optimize=True)
    title().save(os.path.join(TEX, "font/kratos_title.png"), optimize=True)
    icons().save(os.path.join(TEX, "font/kratos_icons.png"), optimize=True)
    pack_icon().save(os.path.join(ROOT, "pack.png"), optimize=True)
    print("tamam")
