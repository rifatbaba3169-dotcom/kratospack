# KratosSMP Menü Paketi

Kratos temalı, yüksek çözünürlüklü (pikselsiz) oyun menüsü resource pack'i.

## Sunucuya ekleme (`server.properties`)

```properties
resource-pack=https://raw.githubusercontent.com/KULLANICI_ADIN/REPO_ADIN/main/dist/KratosSMP-Menu.zip
resource-pack-sha1=b1275aa215f935cb866bb6c8d45da8aae95dba9d
resource-pack-id=4dd9d316-480a-4261-a7f7-417e8085d4c9
require-resource-pack=true
resource-pack-prompt={"text":"KratosSMP menü paketi","color":"red"}
```

> `KULLANICI_ADIN` ve `REPO_ADIN` kısımlarını kendi GitHub bilgilerinle değiştir.
> Pack her güncellendiğinde `python3 tools/build.py` çalıştırıp yeni SHA-1'i yaz,
> mümkünse `resource-pack-id` değerini de yenile (yoksa oyuncularda eski önbellek kalır).

## Geliştirme
- `python3 tools/generate_textures.py` → dokuları yeniden üretir
- `python3 tools/build.py` → `dist/KratosSMP-Menu.zip` + SHA-1
